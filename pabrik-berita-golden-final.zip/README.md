# Pabrik Berita v3.0 - Golden Circular - Deploy Ready

## Logo
- Baru: Golden Circular premium bulat 88px, border 3px #D4AF37, shadow gold
- File: logo.png (dari upload user)
- Fallback: hexagon CSS AMD jika gagal load

## File Included
- index.html (login) - background #0a0a0a + 2 radial gold glow 0.12
- dashboard.html (auth guard)
- logo.png
- favicon.png
- _redirects (Cloudflare)
- .nojekyll (GitHub Pages)

## Login Logic FINAL FIX
USERS = {
  'agungmaydaryus': '@Karimun2019!',
  'agung maydaryus': '@Karimun2019!',
  'editor@meranginkab.go.id': 'Editor2026!',
  'editor': 'Editor2026!',
  'peliput@meranginkab.go.id': 'Peliput2026!',
  'peliput': 'Peliput2026!'
}
EXCLUDED = ['admin@meranginkab.go.id','agung.maydaryus@meranginkab.go.id','admin']
- Jika EXCLUDED -> block
- Sukses -> localStorage isLoggedIn=true + currentUser -> redirect dashboard.html
- Dashboard auth guard: jika tidak isLoggedIn -> redirect index.html
- Logout clear localStorage

## Deploy GitHub Pages
1. Buat repo baru: pabrik-berita
2. Upload semua file dari ZIP ke root repo (atau docs/)
3. Settings > Pages > Source: main / root (atau main / docs)
4. Jika pakai custom path https://username.github.io/pabrik-berita/ pastikan index.html di root
5. .nojekyll wajib agar logo tidak diabaikan Jekyll
6. Akses: https://username.github.io/pabrik-berita/

## Deploy Cloudflare Pages
1. Login dash.cloudflare.com > Pages > Create project > Upload
2. Drag & drop semua file (atau connect GitHub repo)
3. Build settings: None (static)
4. _redirects sudah include untuk SPA fallback
5. Deploy -> dapat URL https://pabrik-berita-xxx.pages.dev
6. Custom domain opsional

## Ukuran File
- index.html < 15KB, tanpa external deps kecuali logo.png
- dashboard.html < 15KB
- Total ZIP < 100KB

Developed by Agung Maydaryus - Ver Pabrik Berita v3.0
